import React, { useState, useEffect, useMemo, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Waves, RefreshCw, Info, ZoomIn, ZoomOut, Move, FlaskConical } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import MapClickInfo from "@/components/MapClickInfo";
import SavedLocations from "@/components/SavedLocations";
import SSTLegend from "@/components/SSTLegend";
import { Link } from "react-router-dom";



// Color scale for SST values (cold → warm)
function sstColor(val, min, max) {
  if (val === null || val === undefined) return "#1e293b";
  const t = Math.max(0, Math.min(1, (val - min) / (max - min)));
  // Blue → Cyan → Green → Yellow → Orange → Red
  const stops = [
    [0, [15, 40, 140]],
    [0.2, [0, 130, 200]],
    [0.4, [0, 200, 180]],
    [0.6, [50, 210, 50]],
    [0.75, [255, 220, 0]],
    [0.9, [255, 120, 0]],
    [1, [220, 30, 30]],
  ];
  let lower = stops[0], upper = stops[stops.length - 1];
  for (let i = 0; i < stops.length - 1; i++) {
    if (t >= stops[i][0] && t <= stops[i + 1][0]) {
      lower = stops[i];
      upper = stops[i + 1];
      break;
    }
  }
  const lt = (t - lower[0]) / (upper[0] - lower[0]);
  const r = Math.round(lower[1][0] + (upper[1][0] - lower[1][0]) * lt);
  const g = Math.round(lower[1][1] + (upper[1][1] - lower[1][1]) * lt);
  const b = Math.round(lower[1][2] + (upper[1][2] - lower[1][2]) * lt);
  return `rgb(${r},${g},${b})`;
}

export default function SSTDashboard() {
  const [summaryData, setSummaryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [savedLocations, setSavedLocations] = useState([]);
  const clearMarkersRef = useRef(null);
  const selectMarkerRef = useRef(null);
  const [legendHoverSst, setLegendHoverSst] = useState(null);
  const [dataSource, setDataSource] = useState('MUR'); // 'MUR' | 'VIIRS'
  const [viirsData, setViirsData] = useState(null);   // { days: [...], available_dates: [...] }
  const [viirsDateIndex, setViirsDateIndex] = useState(0);

  async function fetchSavedLocations() {
    const locs = await base44.entities.SavedLocation.list("-created_date", 100);
    setSavedLocations(locs);
  }

  useEffect(() => { fetchSavedLocations(); }, []);

  async function fetchMUR(date = null) {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("sstSummary", date ? { date } : {});
      setSummaryData(res.data);
      setSelectedDate(res.data.date);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }

  async function fetchVIIRS() {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("getVIIRSData", {});
      setViirsData(res.data);
      setViirsDateIndex(res.data.days.length - 1); // default to most recent
      setSelectedDate(res.data.days[res.data.days.length - 1]?.date ?? null);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }

  // Switch data source
  useEffect(() => {
    if (dataSource === 'MUR') {
      fetchMUR();
    } else {
      fetchVIIRS();
    }
  }, [dataSource]);

  // Keep selectedDate in sync with VIIRS day index
  useEffect(() => {
    if (dataSource === 'VIIRS' && viirsData?.days?.length) {
      setSelectedDate(viirsData.days[viirsDateIndex]?.date ?? null);
    }
  }, [viirsDateIndex]);

  const fetchAll = fetchMUR; // keep existing refresh button working for MUR

  // Active data: VIIRS selected day or MUR summary
  const activeGrid = dataSource === 'VIIRS'
    ? (viirsData?.days?.[viirsDateIndex]?.grid ?? null)
    : summaryData?.grid ?? null;
  const activeStats = dataSource === 'VIIRS'
    ? (viirsData?.days?.[viirsDateIndex]?.stats ?? null)
    : summaryData?.stats ?? null;

  const sstMin = activeStats?.min ?? 32;
  const sstMax = activeStats?.max ?? 85;

  const heatmapData = useMemo(() => {
    if (!activeGrid?.length) return { latSet: [], lonSet: [], grid: {} };
    const latSet = [...new Set(activeGrid.map(d => d.lat))].sort((a, b) => b - a);
    const lonSet = [...new Set(activeGrid.map(d => d.lon))].sort((a, b) => a - b);
    const grid = {};
    activeGrid.forEach(d => { grid[`${d.lat}_${d.lon}`] = d.sst; });
    return { latSet, lonSet, grid };
  }, [activeGrid]);

  const dataBounds = useMemo(() => {
    if (dataSource === 'MUR' && summaryData?.bounds) return summaryData.bounds;
    if (heatmapData.latSet.length && heatmapData.lonSet.length) {
      const { latSet, lonSet } = heatmapData;
      return { south: latSet[latSet.length - 1], north: latSet[0], west: lonSet[0], east: lonSet[lonSet.length - 1] };
    }
    return null;
  }, [dataSource, summaryData, heatmapData]);

  return (
    <div className="h-screen bg-gradient-to-br from-blue-50 via-sky-50 to-slate-100 flex flex-col overflow-hidden">
      {error && (
        <div className="flex-shrink-0 bg-red-50 border-b border-red-200 px-4 py-2 text-xs text-red-600">
          Error: {error}
        </div>
      )}

      {/* ── 2-Column Body ── */}
      <div className="flex-1 flex overflow-hidden">

        {/* Center — Map + Legend */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {loading ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="flex flex-col items-center gap-3">
                <div className="w-10 h-10 border-4 border-slate-200 border-t-cyan-500 rounded-full animate-spin" />
                <p className="text-sm text-slate-500 font-medium">Loading SST data…</p>
              </div>
            </div>
          ) : activeGrid?.length > 0 ? (
            <>
              {/* Map fills remaining space */}
              <div className="flex-1 overflow-hidden p-2 sm:p-3 pb-0">
                <SSTHeatmap
                   data={heatmapData}
                   dataBounds={dataBounds}
                   sstMin={sstMin}
                   sstMax={sstMax}
                   date={selectedDate}
                   onLocationSaved={fetchSavedLocations}
                   clearMarkersRef={clearMarkersRef}
                   selectMarkerRef={selectMarkerRef}
                   onHoverSst={setLegendHoverSst}
                   dataSource={dataSource}
                 />
              </div>

              {/* Legend */}
              <div className="flex-shrink-0 px-2 sm:px-3 pt-2 pb-2 sm:pb-3">
                <SSTLegend sstMin={sstMin} sstMax={sstMax} hoverSst={legendHoverSst} />
              </div>
            </>
          ) : null}
        </main>

        {/* Right Panel — Saved Locations */}
        <aside className="w-56 xl:w-64 flex-shrink-0 flex flex-col border-l border-slate-200 bg-white/60 overflow-y-auto">
          <div className="p-3 border-b border-slate-200">
            <div className="text-xs font-semibold text-slate-600">Saved Locations</div>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            <SavedLocations locations={savedLocations} onRefresh={fetchSavedLocations} onClearMarkers={(id) => clearMarkersRef.current?.(id)} onSelectLocation={(idx, loc) => selectMarkerRef.current?.(idx, loc)} />
          </div>
        </aside>

      </div>
    </div>
  );
}

const BATHY_URL = "https://raw.githubusercontent.com/jlintvet/SSTv2/main/DailySST/bathymetry.json";
const BATHY_CONTOURS_URL = "https://raw.githubusercontent.com/jlintvet/SSTv2/main/DailySST/bathymetry_contours.json";
const COASTLINE_URL = "https://raw.githubusercontent.com/jlintvet/SSTv2/main/DailySST/noaa_coastline.json";
const WRECKS_URL = "https://raw.githubusercontent.com/jlintvet/SSTv2/main/DailySST/wrecks.json";
const LANDMASK_URL = "https://raw.githubusercontent.com/jlintvet/SSTv2/refs/heads/main/DailySST/landmask.json";

const LOCATIONS = [
  { label: "Beaufort Inlet, NC",   lat: 34.6937,  lon: -76.6663,  wreckRegion: "MoreheadNC"     },
  { label: "Hatteras, NC",         lat: 35.18850, lon: -75.75667, wreckRegion: "HatterasNC"     },
  { label: "Oregon Inlet, NC",     lat: 35.7792,  lon: -75.5320,  wreckRegion: "HatterasNC"     },
  { label: "Virginia Beach, VA",   lat: 36.8516,  lon: -75.9792,  wreckRegion: "ChesapeakeMD"   },
  { label: "Ocean City Inlet, MD", lat: 38.3240,  lon: -75.0883,  wreckRegion: "ChesapeakeMD"   },
];

// Haversine distance in nautical miles
function distanceNm(lat1, lon1, lat2, lon2) {
  const R = 3440.065; // nm
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

// Compass bearing in degrees (0-360)
function bearingDeg(lat1, lon1, lat2, lon2) {
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const y = Math.sin(dLon) * Math.cos(lat2 * Math.PI / 180);
  const x = Math.cos(lat1*Math.PI/180)*Math.sin(lat2*Math.PI/180) - Math.sin(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.cos(dLon);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

function bearingLabel(deg) {
  const dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
  return dirs[Math.round(deg / 22.5) % 16];
}

// ── Spatial Heatmap using Canvas with zoom/pan ────────────────────────────────
function SSTHeatmap({ data, dataBounds, sstMin, sstMax, date, onLocationSaved, clearMarkersRef, selectMarkerRef, onHoverSst, dataSource }) {
  const { latSet, lonSet, grid } = data;
  const canvasRef = React.useRef(null);
  const containerRef = React.useRef(null);
  const [minZoom, setMinZoom] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [selectedLocation, setSelectedLocation] = useState(LOCATIONS.find(l => l.label === "Oregon Inlet, NC"));
  const selectedLocationRef = useRef(selectedLocation);
  useEffect(() => { selectedLocationRef.current = selectedLocation; }, [selectedLocation]);
  const dragging = useRef(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const panStart = useRef({ x: 0, y: 0 });
  const [showSSTLayer, setShowSSTLayer] = useState(true);
  const [showBathyLayer, setShowBathyLayer] = useState(true);
  const [showWrecks, setShowWrecks] = useState(false);
  const showJsonContours = showBathyLayer;
  const [bathyData, setBathyData] = useState(null);
  const [bathyLoading, setBathyLoading] = useState(false);
  const [bathyContours, setBathyContours] = useState(null);
  const [jsonContours, setJsonContours] = useState(null);
  const [jsonContoursLoading, setJsonContoursLoading] = useState(false);
  const jsonCanvasRef = React.useRef(null);
  const [wrecksData, setWrecksData] = useState(null);
  const [wrecksLoading, setWrecksLoading] = useState(false);
  const [landMaskData, setLandMaskData] = useState(null);
  const landCanvasRef = React.useRef(null);
  const [showCoastline, setShowCoastline] = useState(true);
  const [coastlineData, setCoastlineData] = useState(null);
  const [coastlineLoading, setCoastlineLoading] = useState(false);
  const coastlineCanvasRef = React.useRef(null);
  const [hoveredWreck, setHoveredWreck] = useState(null);
  const [clickInfo, setClickInfo] = useState(null);
  const [markers, setMarkers] = useState([]);
  const [hoverInfo, setHoverInfo] = useState(null); // { px, py, sst, depth_ft }
  const [selectedMarker, setSelectedMarker] = useState(null); // { index, px, py, mk }
  const [savedWreckKeys, setSavedWreckKeys] = useState(new Set()); // "lat_lon" keys of saved wrecks

  // Calculate minZoom so the data fills the container, then center
  React.useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const cw = container.clientWidth;
    const ch = container.clientHeight;
    const mz = Math.max(cw / BASE_W, ch / BASE_H);
    setMinZoom(mz);
    setZoom(mz);
    const scaledW = BASE_W * mz;
    const scaledH = BASE_H * mz;
    setPan({ x: (cw - scaledW) / 2, y: (ch - scaledH) / 2 });
  }, [boundsKey]);

  // Expose clearMarkers to parent via ref (id=null clears all, id=string removes one)
  React.useEffect(() => {
    if (clearMarkersRef) clearMarkersRef.current = (id) => {
      if (id === null) {
        setMarkers([]);
        setSelectedMarker(null);
      } else {
        setMarkers(m => m.filter(mk => mk.id !== id));
        setSelectedMarker(sm => sm?.mk?.id === id ? null : sm);
      }
    };
  }, [clearMarkersRef]);

  // Expose selectMarker to parent via ref
  React.useEffect(() => {
    if (selectMarkerRef) selectMarkerRef.current = (idx, loc) => {
      const marker = markers.find(m => m.id === loc.id);
      if (marker) {
        const markerIdx = markers.indexOf(marker);
        const relX = (marker.lon - BOUNDS.west) / LON_RANGE;
        const relY = (BOUNDS.north - marker.lat) / LAT_RANGE;
        const px = pan.x + relX * BASE_W * zoom;
        const py = pan.y + relY * BASE_H * zoom;
        setSelectedMarker({ index: markerIdx, px, py, mk: marker });
      }
    };
  }, [selectMarkerRef, markers, pan, zoom]);

  const BOUNDS = dataBounds || { north: 39.00, south: 33.70, west: -78.89, east: -72.21 };

  const LON_RANGE = BOUNDS.east - BOUNDS.west;
  const LAT_RANGE = BOUNDS.north - BOUNDS.south;

  // Base logical canvas size — width fixed, height derived from aspect ratio
  const BASE_W = 900;
  const BASE_H = Math.round(BASE_W * (LAT_RANGE / LON_RANGE));



  // Scale canvas resolution by zoom * devicePixelRatio for crisp rendering
  const dpr = window.devicePixelRatio || 1;
  const scale = zoom * dpr;
  const W = Math.round(BASE_W * scale);
  const H = Math.round(BASE_H * scale);

  // Unified coordinate mapping — all layers use these
  const toCanvasX = (lon) => ((lon - BOUNDS.west) / LON_RANGE) * W;
  const toCanvasY = (lat) => ((BOUNDS.north - lat) / LAT_RANGE) * H;

  // Re-fit when bounds or container size changes
  const boundsKey = dataBounds ? `${dataBounds.north}_${dataBounds.south}_${dataBounds.west}_${dataBounds.east}` : 'default';

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, W, H);
    if (!showSSTLayer) return;
    // Cell size based on BOUNDS grid resolution
    const cellW = (W / LON_RANGE) * (lonSet.length > 1 ? lonSet[1] - lonSet[0] : LON_RANGE / lonSet.length);
    const cellH = (H / LAT_RANGE) * (latSet.length > 1 ? latSet[0] - latSet[1] : LAT_RANGE / latSet.length);
    for (const lat of latSet) {
      for (const lon of lonSet) {
        const sst = grid[`${lat}_${lon}`] ?? null;
        if (sst === null) continue;
        const x = Math.floor(toCanvasX(lon));
        const y = Math.floor(toCanvasY(lat));
        const x2 = Math.ceil(toCanvasX(lon) + cellW + 1);
        const y2 = Math.ceil(toCanvasY(lat) + cellH + 1);
        ctx.fillStyle = sstColor(sst, sstMin, sstMax);
        ctx.fillRect(x, y, x2 - x, y2 - y);
      }
    }
  }, [data, sstMin, sstMax, zoom, showSSTLayer]);

  // Fetch bathymetry eagerly on mount (so depth is always available on click)
  React.useEffect(() => {
    if (bathyData) return;
    fetch(BATHY_URL)
      .then(r => r.json())
      .then(d => { setBathyData(d); })
      .catch(() => {});
  }, []);

  // Fetch land mask eagerly on mount
  React.useEffect(() => {
    if (landMaskData) return;
    fetch(LANDMASK_URL)
      .then(r => r.json())
      .then(d => { setLandMaskData(d); })
      .catch(() => {});
  }, []);

  // Draw land mask layer — only for GOES-19
  React.useEffect(() => {
    const canvas = landCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (dataSource !== 'VIIRS' || !landMaskData?.points?.length) return;
    const BIN = 0.05;
    const cellW = (W / LON_RANGE) * BIN;
    const cellH = (H / LAT_RANGE) * BIN;
    ctx.fillStyle = "rgba(90, 100, 110, 0.92)";
    for (const pt of landMaskData.points) {
      const x = Math.floor(toCanvasX(pt.lon));
      const y = Math.floor(toCanvasY(pt.lat));
      ctx.fillRect(x, y, Math.ceil(cellW) + 1, Math.ceil(cellH) + 1);
    }
  }, [landMaskData, zoom, dataSource]);

  // Fetch pre-calculated JSON contours
  React.useEffect(() => {
    if (!showJsonContours || jsonContours) return;
    setJsonContoursLoading(true);
    fetch(BATHY_CONTOURS_URL)
      .then(r => r.json())
      .then(d => { setJsonContours(d); setJsonContoursLoading(false); })
      .catch(() => setJsonContoursLoading(false));
  }, [showJsonContours]);

  // Fetch coastline data
  React.useEffect(() => {
    if (!showCoastline || coastlineData) return;
    setCoastlineLoading(true);
    fetch(COASTLINE_URL)
      .then(r => r.json())
      .then(d => { setCoastlineData(d); setCoastlineLoading(false); })
      .catch(() => setCoastlineLoading(false));
  }, [showCoastline]);

  // Draw coastline layer
  React.useEffect(() => {
    const canvas = coastlineCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!showCoastline || !coastlineData?.features) return;
    ctx.strokeStyle = "rgba(60,60,60,0.9)";
    ctx.lineWidth = 1.5;
    coastlineData.features.forEach(feature => {
      const coords = feature.geometry?.coordinates;
      if (!coords) return;
      ctx.beginPath();
      coords.forEach(([lon, lat], i) => {
        const x = toCanvasX(lon);
        const y = toCanvasY(lat);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      });
      ctx.stroke();
    });
  }, [showCoastline, coastlineData, zoom]);

  // Fetch wrecks data
  React.useEffect(() => {
    if (!showWrecks || wrecksData) return;
    setWrecksLoading(true);
    fetch(WRECKS_URL)
      .then(r => r.json())
      .then(d => { setWrecksData(d); setWrecksLoading(false); })
      .catch(() => setWrecksLoading(false));
  }, [showWrecks]);

  // Draw JSON contour lines
  React.useEffect(() => {
    const canvas = jsonCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!showJsonContours || !jsonContours?.features) return;

    const depthColors = {
      30:   "rgba(180,230,255,0.9)",
      60:   "rgba(150,215,250,0.9)",
      100:  "rgba(120,200,240,0.9)",
      200:  "rgba(60,160,220,0.9)",
      300:  "rgba(40,130,200,0.9)",
      600:  "rgba(30,110,190,0.9)",
      1000: "rgba(20,75,160,0.9)",
      1500: "rgba(15,55,145,0.9)",
      2000: "rgba(10,30,100,0.9)",
    };
    const heavyDepths = new Set([100, 300, 600]);

    // Draw non-coastline features first
    jsonContours.features.forEach(feature => {
      if (feature.properties.type === "coastline") return;
      const depth = feature.properties.depth_ft;
      ctx.beginPath();
      ctx.strokeStyle = depthColors[depth] || "rgba(100,150,200,0.8)";
      ctx.lineWidth = heavyDepths.has(depth) ? 1.5 : 0.8;
      const coords = feature.geometry.coordinates;
      coords.forEach(([lon, lat], i) => {
        const x = toCanvasX(lon);
        const y = toCanvasY(lat);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      });
      ctx.stroke();
    });

    // Draw coastline features on top
    jsonContours.features.forEach(feature => {
      if (feature.properties.type !== "coastline") return;
      ctx.beginPath();
      ctx.strokeStyle = "rgba(60,60,60,0.9)";
      ctx.lineWidth = 1.5;
      const coords = feature.geometry.coordinates;
      coords.forEach(([lon, lat], i) => {
        const x = toCanvasX(lon);
        const y = toCanvasY(lat);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      });
      ctx.stroke();
    });
  }, [showJsonContours, jsonContours, zoom, showBathyLayer]);

  // Clamp pan so canvas edges stay within viewport
  function clampPan(x, y, z) {
    const container = containerRef.current;
    if (!container) return { x, y };
    const cw = container.clientWidth;
    const ch = container.clientHeight;
    const scaledW = BASE_W * z;
    const scaledH = BASE_H * z;
    // If scaled dimension is smaller than container, center it; otherwise clamp to edges
    const minX = scaledW < cw ? (cw - scaledW) / 2 : cw - scaledW;
    const maxX = scaledW < cw ? (cw - scaledW) / 2 : 0;
    const minY = scaledH < ch ? (ch - scaledH) / 2 : ch - scaledH;
    const maxY = scaledH < ch ? (ch - scaledH) / 2 : 0;
    return {
      x: Math.min(maxX, Math.max(minX, x)),
      y: Math.min(maxY, Math.max(minY, y)),
    };
  }

  function handleZoomIn() {
    const container = containerRef.current;
    const cx = container ? container.clientWidth / 2 : 0;
    const cy = container ? container.clientHeight / 2 : 0;
    setZoom(z => {
      const nz = Math.min(z * 1.5, 10);
      setPan(p => {
        const np = {
          x: cx - (cx - p.x) * (nz / z),
          y: cy - (cy - p.y) * (nz / z),
        };
        return clampPan(np.x, np.y, nz);
      });
      return nz;
    });
  }
  function handleZoomOut() {
    const container = containerRef.current;
    const cx = container ? container.clientWidth / 2 : 0;
    const cy = container ? container.clientHeight / 2 : 0;
    setZoom(z => {
      const nz = Math.max(z / 1.5, minZoom);
      setPan(p => clampPan(
        cx - (cx - p.x) * (nz / z),
        cy - (cy - p.y) * (nz / z),
        nz
      ));
      return nz;
    });
  }
  function handleReset() {
    const container = containerRef.current;
    if (!container) return;
    const cw = container.clientWidth;
    const ch = container.clientHeight;
    setZoom(minZoom);
    setPan({ x: (cw - BASE_W * minZoom) / 2, y: (ch - BASE_H * minZoom) / 2 });
  }

  // Touch state refs
  const touchStartRef = useRef(null); // { x, y, pan, zoom } for single-finger pan
  const pinchStartRef = useRef(null); // { dist, zoom, midX, midY, pan } for pinch

  function getTouchDist(touches) {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function onTouchStart(e) {
    e.preventDefault();
    if (e.touches.length === 1) {
      touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, pan: { ...pan } };
      pinchStartRef.current = null;
    } else if (e.touches.length === 2) {
      const dist = getTouchDist(e.touches);
      const container = containerRef.current;
      const rect = container.getBoundingClientRect();
      const midX = ((e.touches[0].clientX + e.touches[1].clientX) / 2) - rect.left;
      const midY = ((e.touches[0].clientY + e.touches[1].clientY) / 2) - rect.top;
      pinchStartRef.current = { dist, zoom, midX, midY, pan: { ...pan } };
      touchStartRef.current = null;
    }
  }

  function onTouchMove(e) {
    e.preventDefault();
    if (e.touches.length === 1 && touchStartRef.current) {
      const dx = e.touches[0].clientX - touchStartRef.current.x;
      const dy = e.touches[0].clientY - touchStartRef.current.y;
      const np = clampPan(touchStartRef.current.pan.x + dx, touchStartRef.current.pan.y + dy, zoom);
      setPan(np);
    } else if (e.touches.length === 2 && pinchStartRef.current) {
      const newDist = getTouchDist(e.touches);
      const scale = newDist / pinchStartRef.current.dist;
      const nz = Math.min(10, Math.max(minZoom, pinchStartRef.current.zoom * scale));
      const { midX, midY } = pinchStartRef.current;
      const np = {
        x: midX - (midX - pinchStartRef.current.pan.x) * (nz / pinchStartRef.current.zoom),
        y: midY - (midY - pinchStartRef.current.pan.y) * (nz / pinchStartRef.current.zoom),
      };
      setZoom(nz);
      setPan(clampPan(np.x, np.y, nz));
    }
  }

  function onTouchEnd(e) {
    if (e.touches.length === 0) {
      touchStartRef.current = null;
      pinchStartRef.current = null;
    }
  }

  function onMouseDown(e) {
    dragging.current = true;
    dragStart.current = { x: e.clientX, y: e.clientY };
    panStart.current = { ...pan };
  }
  function onMouseMove(e) {
    const container = containerRef.current;
    if (dragging.current) {
      const dx = e.clientX - dragStart.current.x;
      const dy = e.clientY - dragStart.current.y;
      const np = clampPan(panStart.current.x + dx, panStart.current.y + dy, zoom);
      setPan(np);
      setHoverInfo(null);
      return;
    }
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const relX = (e.clientX - rect.left - pan.x) / (BASE_W * zoom);
    const relY = (e.clientY - rect.top - pan.y) / (BASE_H * zoom);
    if (relX < 0 || relX > 1 || relY < 0 || relY > 1) { setHoverInfo(null); return; }
    const lon = BOUNDS.west + relX * LON_RANGE;
    const lat = BOUNDS.north - relY * LAT_RANGE;
    if (lon < BOUNDS.west || lon > BOUNDS.east || lat < BOUNDS.south || lat > BOUNDS.north) { setHoverInfo(null); return; }
    const nearLat = latSet.reduce((a, b) => Math.abs(b - lat) < Math.abs(a - lat) ? b : a);
    const nearLon = lonSet.reduce((a, b) => Math.abs(b - lon) < Math.abs(a - lon) ? b : a);
    const sst = grid[`${nearLat}_${nearLon}`] ?? null;
    let depth_ft = null;
    if (bathyData?.points?.length) {
      let best = null, bestDist = Infinity;
      for (const pt of bathyData.points) {
        const d = (pt.lat - lat) ** 2 + (pt.lon - lon) ** 2;
        if (d < bestDist) { bestDist = d; best = pt; }
      }
      depth_ft = best?.depth_ft ?? null;
    }
    const refLoc = selectedLocationRef.current;
    const dist = refLoc ? distanceNm(refLoc.lat, refLoc.lon, lat, lon) : null;
    const bearing = refLoc ? bearingDeg(refLoc.lat, refLoc.lon, lat, lon) : null;
    setHoverInfo({ px: e.clientX - rect.left, py: e.clientY - rect.top, sst, depth_ft, dist, bearing });
    onHoverSst?.(sst);
  }
  function onMouseUp() { dragging.current = false; }
  function onMouseLeave() { dragging.current = false; setHoverInfo(null); setHoveredWreck(null); onHoverSst?.(null); }

  function onMapClick(e) {
    // Don't fire click if user was dragging
    const dx = Math.abs(e.clientX - dragStart.current.x);
    const dy = Math.abs(e.clientY - dragStart.current.y);
    if (dx > 4 || dy > 4) return;

    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    // Position relative to the panned/zoomed canvas
    const relX = (e.clientX - rect.left - pan.x) / (BASE_W * zoom);
    const relY = (e.clientY - rect.top - pan.y) / (BASE_H * zoom);
    if (relX < 0 || relX > 1 || relY < 0 || relY > 1) return;

    const lon = BOUNDS.west + relX * LON_RANGE;
    const lat = BOUNDS.north - relY * LAT_RANGE;

    // Nearest SST grid point
    const nearLat = latSet.reduce((a, b) => Math.abs(b - lat) < Math.abs(a - lat) ? b : a);
    const nearLon = lonSet.reduce((a, b) => Math.abs(b - lon) < Math.abs(a - lon) ? b : a);
    const sst = grid[`${nearLat}_${nearLon}`] ?? null;

    // Estimate depth from bathyData if loaded
    let depth_ft = null;
    if (bathyData?.points?.length) {
      let best = null, bestDist = Infinity;
      for (const pt of bathyData.points) {
        const d = (pt.lat - lat) ** 2 + (pt.lon - lon) ** 2;
        if (d < bestDist) { bestDist = d; best = pt; }
      }
      depth_ft = best?.depth_ft ?? null;
    }

    const refLoc = selectedLocationRef.current;
    const dist = refLoc ? distanceNm(refLoc.lat, refLoc.lon, lat, lon) : null;
    const bearing = refLoc ? bearingDeg(refLoc.lat, refLoc.lon, lat, lon) : null;
    setClickInfo({
      lat, lon, sst, depth_ft, dist, bearing,
      locationLabel: refLoc?.label ?? null,
      px: e.clientX - rect.left,
      py: e.clientY - rect.top,
    });
  }

  const onWheelRef = useRef(null);
  onWheelRef.current = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const cy = e.clientY - rect.top;
    const factor = e.deltaY > 0 ? 1 / 1.15 : 1.15;
    setZoom(z => {
      const nz = Math.min(10, Math.max(minZoom, z * factor));
      setPan(p => clampPan(
        cx - (cx - p.x) * (nz / z),
        cy - (cy - p.y) * (nz / z),
        nz
      ));
      return nz;
    });
  };

  if (!latSet || !latSet.length) return null;

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-2 sm:p-3 h-full flex flex-col">
      <div className="flex items-center justify-between mb-2 flex-shrink-0">
        <h2 className="text-xs font-semibold text-slate-600">SST Spatial Distribution — {date}</h2>
        <Badge variant="outline" className="text-xs text-slate-500 border-slate-300 bg-slate-50">
          {latSet.length} × {lonSet.length} pts
        </Badge>
      </div>
      <div className="relative flex gap-2 flex-1 min-h-0">
        <div
          ref={(el) => {
            containerRef.current = el;
            if (el) {
              const handler = (e) => onWheelRef.current(e);
              el._wheelHandler && el.removeEventListener("wheel", el._wheelHandler);
              el._wheelHandler = handler;
              el.addEventListener("wheel", handler, { passive: false });
            }
          }}
          className="flex-1 overflow-hidden rounded relative"
          style={{ cursor: "crosshair", touchAction: "none" }}
          onMouseDown={onMouseDown}
          onMouseMove={onMouseMove}
          onMouseUp={onMouseUp}
          onMouseLeave={onMouseLeave}
          onClick={onMapClick}
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          <div style={{ transform: `translate(${pan.x}px, ${pan.y}px)`, transformOrigin: "0 0", position: "relative", width: `${BASE_W * zoom}px`, height: `${BASE_H * zoom}px` }}>
            <canvas ref={canvasRef} width={W} height={H} style={{ width: `${BASE_W * zoom}px`, height: `${BASE_H * zoom}px`, display: "block" }} />
            <canvas ref={jsonCanvasRef} width={W} height={H} style={{ width: `${BASE_W * zoom}px`, height: `${BASE_H * zoom}px`, display: "block", position: "absolute", top: 0, left: 0, pointerEvents: "none" }} />
            <canvas ref={landCanvasRef} width={W} height={H} style={{ width: `${BASE_W * zoom}px`, height: `${BASE_H * zoom}px`, display: "block", position: "absolute", top: 0, left: 0, pointerEvents: "none" }} />
            <canvas ref={coastlineCanvasRef} width={W} height={H} style={{ width: `${BASE_W * zoom}px`, height: `${BASE_H * zoom}px`, display: "block", position: "absolute", top: 0, left: 0, pointerEvents: "none" }} />
          </div>
          {clickInfo && (
            <MapClickInfo
              info={clickInfo}
              date={date}
              onClose={() => setClickInfo(null)}
              onSaved={(info) => {
                setMarkers(m => [...m, { lat: info.lat, lon: info.lon, sst: info.sst, depth_ft: info.depth_ft, label: info.label, id: info.id, dist_nm: info.dist, bearing_deg: info.bearing != null ? Math.round(info.bearing) : null, bearing_cardinal: info.bearing != null ? bearingLabel(info.bearing) : null, from_location: info.locationLabel }]);
                setSavedWreckKeys(s => new Set([...s, `${info.lat}_${info.lon}`]));
                onLocationSaved();
              }}
            />
          )}
          {/* Hover tooltip */}
          {hoverInfo && !clickInfo && (
            <div
              className="absolute z-30 pointer-events-none bg-white/95 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs shadow-lg space-y-0.5"
              style={{ left: hoverInfo.px + 14, top: hoverInfo.py - 10 }}
            >
              {hoverInfo.sst != null && <div className="text-cyan-600 font-semibold">{hoverInfo.sst.toFixed(1)}°F</div>}
              {hoverInfo.depth_ft != null && <div className="text-blue-600 font-medium">{Math.round(hoverInfo.depth_ft)} ft</div>}
              {hoverInfo.dist != null && <div className="text-slate-600">{hoverInfo.dist.toFixed(1)} nm · {Math.round(hoverInfo.bearing)}° {bearingLabel(hoverInfo.bearing)}</div>}
              {hoverInfo.sst == null && hoverInfo.depth_ft == null && <div className="text-slate-400">No data</div>}
            </div>
          )}

          {/* Wreck markers overlay */}
          {showWrecks && wrecksData?.features?.map((feature, i) => {
            const [lon, lat] = feature.geometry.coordinates;
            if (lat < BOUNDS.south || lat > BOUNDS.north || lon < BOUNDS.west || lon > BOUNDS.east) return null;
            if (savedWreckKeys.has(`${lat}_${lon}`)) return null;
            // Filter by selected location's wreck region
            const props = feature.properties || {};
            if (selectedLocation?.wreckRegion && props.region && props.region !== selectedLocation.wreckRegion) return null;

            const relX = (lon - BOUNDS.west) / LON_RANGE;
            const relY = (BOUNDS.north - lat) / LAT_RANGE;
            const px = pan.x + relX * BASE_W * zoom;
            const py = pan.y + relY * BASE_H * zoom;
            const isDangerous = props.wreck_type === "dangerous";
            return (
              <div
                key={`wreck-${i}`}
                style={{ position: "absolute", left: px - 5, top: py - 5, zIndex: 8, cursor: "pointer" }}
                onMouseEnter={() => setHoveredWreck({ px, py, lat, lon, props })}
                onMouseLeave={() => {}}
                onClick={e => { e.stopPropagation(); setHoveredWreck(hw => hw?.props === props ? null : { px, py, lat, lon, props }); }}
              >
                <svg width="10" height="10" viewBox="0 0 10 10">
                  <polygon points="5,0 10,10 0,10" fill={isDangerous ? "#ef4444" : "#f59e0b"} stroke="white" strokeWidth="0.8" opacity="0.9"/>
                </svg>
              </div>
            );
          })}

          {/* Wreck hover tooltip */}
          {hoveredWreck && (
            <div
              className="absolute z-30 bg-white border border-amber-300 rounded-lg px-2.5 py-2 text-xs shadow-lg min-w-40"
              style={{ left: hoveredWreck.px + 12, top: hoveredWreck.py - 10 }}
              onMouseEnter={() => {}}
              onMouseLeave={() => setHoveredWreck(null)}
            >
              <div className="text-amber-600 font-semibold mb-1">⚓ {hoveredWreck.props.name || hoveredWreck.props.symbol || "Unknown"}</div>
              {hoveredWreck.props.symbol && <div className="text-slate-500">{hoveredWreck.props.symbol}</div>}
              {hoveredWreck.props.depth_ft != null && <div className="text-blue-600 font-medium">🌊 {Math.round(hoveredWreck.props.depth_ft)} ft</div>}
              {hoveredWreck.props.year_sunk && <div className="text-slate-500">Sunk: {hoveredWreck.props.year_sunk}</div>}
              <button
                className="mt-2 w-full flex items-center justify-center gap-1 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold py-1 rounded-lg transition-colors shadow-sm"
                onClick={(e) => {
                  e.stopPropagation();
                  const container = containerRef.current;
                  const rect = container.getBoundingClientRect();
                  const [lon, lat] = [hoveredWreck.lon, hoveredWreck.lat];
                  const nearLat = latSet.reduce((a, b) => Math.abs(b - lat) < Math.abs(a - lat) ? b : a);
                  const nearLon = lonSet.reduce((a, b) => Math.abs(b - lon) < Math.abs(a - lon) ? b : a);
                  const sst = grid[`${nearLat}_${nearLon}`] ?? null;
                  let depth_ft = null;
                  if (bathyData?.points?.length) {
                    let best = null, bestDist = Infinity;
                    for (const pt of bathyData.points) {
                      const d = (pt.lat - lat) ** 2 + (pt.lon - lon) ** 2;
                      if (d < bestDist) { bestDist = d; best = pt; }
                    }
                    depth_ft = best?.depth_ft ?? null;
                  }
                  const refLoc = selectedLocationRef.current;
                  const dist = refLoc ? distanceNm(refLoc.lat, refLoc.lon, lat, lon) : null;
                  const bearing = refLoc ? bearingDeg(refLoc.lat, refLoc.lon, lat, lon) : null;
                  setClickInfo({
                    lat, lon, sst, depth_ft, dist, bearing,
                    locationLabel: refLoc?.label ?? null,
                    prefillLabel: hoveredWreck.props.name || hoveredWreck.props.symbol || "",
                    px: hoveredWreck.px,
                    py: hoveredWreck.py,
                  });
                  setHoveredWreck(null);
                }}
              >
                📌 Save Location
              </button>
            </div>
          )}

          {/* Reference location blue marker */}
          {(() => {
            if (!selectedLocation) return null;
            const relX = (selectedLocation.lon - BOUNDS.west) / LON_RANGE;
            const relY = (BOUNDS.north - selectedLocation.lat) / LAT_RANGE;
            const px = pan.x + relX * BASE_W * zoom;
            const py = pan.y + relY * BASE_H * zoom;
            if (px < -10 || px > BASE_W * zoom + 10 || py < -10 || py > BASE_H * zoom + 10) return null;
            return (
              <div key="ref-loc" style={{ position: "absolute", left: px - 8, top: py - 20, zIndex: 11, pointerEvents: "none" }}>
                <svg width="16" height="22" viewBox="0 0 16 22" fill="none">
                  <path d="M8 0C3.582 0 0 3.582 0 8c0 6 8 14 8 14s8-8 8-14c0-4.418-3.582-8-8-8z" fill="#3b82f6" stroke="#1d4ed8" strokeWidth="1"/>
                  <circle cx="8" cy="8" r="3" fill="white"/>
                </svg>
                <div style={{ position: "absolute", top: 24, left: "50%", transform: "translateX(-50%)", whiteSpace: "nowrap", fontSize: 9, color: "#93c5fd", background: "rgba(15,23,42,0.85)", borderRadius: 4, padding: "1px 4px" }}>
                  {selectedLocation.label}
                </div>
              </div>
            );
          })()}

          {/* Saved location markers — positioned in container space, not inside the panned div */}
          {markers.map((mk, i) => {
            const relX = (mk.lon - BOUNDS.west) / LON_RANGE;
            const relY = (BOUNDS.north - mk.lat) / LAT_RANGE;
            const px = pan.x + relX * BASE_W * zoom;
            const py = pan.y + relY * BASE_H * zoom;
            const isSelected = selectedMarker?.index === i;
            return (
              <div
                key={i}
                style={{ position: "absolute", left: px - 6, top: py - 14, zIndex: 10, cursor: "pointer" }}
                onClick={e => {
                  e.stopPropagation();
                  setSelectedMarker(isSelected ? null : { index: i, px, py, mk });
                  setClickInfo(null);
                }}
              >
                {isSelected && (
                  <svg style={{ position: "absolute", left: -15, top: -15 }} width="42" height="44" viewBox="0 0 42 44" fill="none">
                    <circle cx="21" cy="22" r="14" fill="rgba(251, 146, 60, 0.2)" stroke="#fb923c" strokeWidth="1.5" />
                  </svg>
                )}
                <svg width="12" height="16" viewBox="0 0 12 16" fill="none">
                  <path d="M6 0C2.686 0 0 2.686 0 6c0 4.5 6 10 6 10s6-5.5 6-10c0-3.314-2.686-6-6-6z" fill={isSelected ? "#fb923c" : "#f97316"}/>
                  <circle cx="6" cy="6" r="2.5" fill="white"/>
                </svg>
              </div>
            );
          })}

          {/* Selected marker popup */}
          {selectedMarker && (
            <div
              className="absolute z-20 bg-white border border-slate-200 rounded-xl shadow-xl p-3 w-52 text-xs"
              style={{ left: selectedMarker.px + 12, top: selectedMarker.py - 40, cursor: "default" }}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-800 font-semibold truncate">{selectedMarker.mk.label || "Saved Location"}</span>
                <button onClick={() => setSelectedMarker(null)} className="text-slate-400 hover:text-slate-700 ml-2 flex-shrink-0">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor"><path d="M10.5 3.5l-7 7M3.5 3.5l7 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
                </button>
              </div>
              <div className="space-y-1 mb-2">
                <div className="flex justify-between"><span className="text-slate-500">Lat</span><span className="text-slate-800 font-mono font-semibold">{selectedMarker.mk.lat.toFixed(4)}°N</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Lon</span><span className="text-slate-800 font-mono font-semibold">{selectedMarker.mk.lon.toFixed(4)}°E</span></div>
                {selectedMarker.mk.sst != null && <div className="flex justify-between"><span className="text-slate-500">Temp</span><span className="text-cyan-600 font-semibold">{selectedMarker.mk.sst.toFixed(1)}°F</span></div>}
                {selectedMarker.mk.depth_ft != null && <div className="flex justify-between"><span className="text-slate-500">Depth</span><span className="text-blue-600 font-semibold">{Math.round(selectedMarker.mk.depth_ft)} ft</span></div>}
                {selectedMarker.mk.dist_nm != null && <div className="flex justify-between"><span className="text-slate-500">Distance</span><span className="text-slate-700">{selectedMarker.mk.dist_nm.toFixed(1)} nm</span></div>}
                {selectedMarker.mk.bearing_deg != null && <div className="flex justify-between"><span className="text-slate-500">Bearing</span><span className="text-slate-700">{selectedMarker.mk.bearing_deg}° {selectedMarker.mk.bearing_cardinal}</span></div>}
                {selectedMarker.mk.from_location && <div className="flex justify-between"><span className="text-slate-500">From</span><span className="text-slate-700">{selectedMarker.mk.from_location}</span></div>}
              </div>
              <button
                onClick={async () => {
                  const mk = selectedMarker.mk;
                  if (mk.id) await base44.entities.SavedLocation.delete(mk.id);
                  setMarkers(m => m.filter((_, idx) => idx !== selectedMarker.index));
                  setSelectedMarker(null);
                  onLocationSaved();
                }}
                className="w-full flex items-center justify-center gap-1.5 bg-red-500 hover:bg-red-600 text-white text-xs font-semibold py-1.5 rounded-lg transition-colors shadow-sm"
              >
                🗑️ Delete Marker
              </button>
            </div>
          )}
        </div>

        {/* Map controls — bottom strip on mobile, right panel on sm+ */}
        {/* Mobile: horizontal bar at bottom */}
        <div className="sm:hidden absolute bottom-0 left-0 right-0 z-20 flex items-center gap-1.5 bg-white/90 backdrop-blur-sm border-t border-slate-200 px-2 py-1.5 shadow-lg">
          <select
            value={selectedLocation.label}
            onChange={e => setSelectedLocation(LOCATIONS.find(l => l.label === e.target.value))}
            className="flex-1 bg-white border border-slate-300 text-slate-700 text-[11px] rounded-lg px-2 py-1.5 focus:outline-none focus:border-cyan-500 min-w-0"
          >
            {LOCATIONS.map(l => <option key={l.label} value={l.label}>{l.label}</option>)}
          </select>
          <button
            onClick={() => setShowSSTLayer(s => !s)}
            className={`text-[11px] font-semibold px-2.5 py-1.5 rounded-lg transition-colors flex-shrink-0 ${showSSTLayer ? "bg-cyan-600 text-white shadow-sm" : "bg-white text-slate-600 border border-slate-300"}`}
            title="SST Layer"
          >🌡️</button>
          <button
            onClick={() => setShowBathyLayer(b => !b)}
            className={`text-[11px] font-semibold px-2.5 py-1.5 rounded-lg transition-colors flex-shrink-0 ${showBathyLayer ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 border border-slate-300"}`}
            title="Bathy Contours"
          >{jsonContoursLoading ? "…" : "🗺️"}</button>
          <button
            onClick={() => setShowWrecks(w => !w)}
            className={`text-[11px] font-semibold px-2.5 py-1.5 rounded-lg border transition-colors flex-shrink-0 ${showWrecks ? "bg-amber-500 text-white border-amber-400" : "bg-white text-slate-600 border-slate-300"}`}
            title="Wrecks"
          >
            ⚓
          </button>
          <button
            onClick={() => setShowCoastline(c => !c)}
            className={`text-[11px] font-semibold px-2.5 py-1.5 rounded-lg border transition-colors flex-shrink-0 ${showCoastline ? "bg-slate-700 text-white border-slate-600" : "bg-white text-slate-600 border-slate-300"}`}
            title="Coastline"
          >
            {coastlineLoading ? "…" : "🗾"}
          </button>
          <div className="flex gap-1 flex-shrink-0">
            <button onClick={handleZoomIn} className="p-1.5 rounded-lg bg-white border border-slate-300 text-slate-600" title="Zoom in"><ZoomIn className="w-3.5 h-3.5" /></button>
            <button onClick={handleZoomOut} className="p-1.5 rounded-lg bg-white border border-slate-300 text-slate-600" title="Zoom out"><ZoomOut className="w-3.5 h-3.5" /></button>
          </div>
        </div>

        {/* Desktop: right vertical panel */}
        <div className="hidden sm:flex absolute right-0 top-0 z-20 flex-col gap-1.5 items-stretch bg-white/90 backdrop-blur-sm border border-slate-200 rounded-xl p-2 shadow-md" style={{ width: 142 }}>
          <select
            value={selectedLocation.label}
            onChange={e => setSelectedLocation(LOCATIONS.find(l => l.label === e.target.value))}
            className="bg-white border border-slate-300 text-slate-700 text-[11px] rounded-lg px-2 py-1.5 focus:outline-none focus:border-cyan-500 w-full"
          >
            {LOCATIONS.map(l => <option key={l.label} value={l.label}>{l.label}</option>)}
          </select>

          <div className="border-t border-slate-200 my-0.5" />

          <button
            onClick={() => setShowSSTLayer(s => !s)}
            className={`text-[11px] font-semibold px-2 py-1.5 rounded-lg transition-colors text-left ${showSSTLayer ? "bg-cyan-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-50 border border-slate-300"}`}
          >🌡️ SST</button>
          <button
            onClick={() => setShowBathyLayer(b => !b)}
            className={`text-[11px] font-semibold px-2 py-1.5 rounded-lg transition-colors text-left ${showBathyLayer ? "bg-blue-600 text-white shadow-sm" : "bg-white text-slate-600 hover:bg-slate-50 border border-slate-300"}`}
          >{jsonContoursLoading ? "Loading…" : "🗺️ Bathy"}</button>

          <div className="border-t border-slate-200 my-0.5" />

          <button
            onClick={() => setShowWrecks(w => !w)}
            className={`text-[11px] font-semibold px-2 py-1.5 rounded-lg border transition-colors text-left ${showWrecks ? "bg-amber-500 text-white border-amber-400" : "bg-white text-slate-600 border-slate-300 hover:bg-slate-50"}`}
          >
            {wrecksLoading ? "Loading…" : "⚓ Wrecks"}
          </button>
          <button
            onClick={() => setShowCoastline(c => !c)}
            className={`text-[11px] font-semibold px-2 py-1.5 rounded-lg border transition-colors text-left ${showCoastline ? "bg-slate-700 text-white border-slate-600" : "bg-white text-slate-600 border-slate-300 hover:bg-slate-50"}`}
          >
            {coastlineLoading ? "Loading…" : "🗾 Coastline"}
          </button>

          <div className="border-t border-slate-200 my-0.5" />

          <div className="flex gap-1">
            <button onClick={handleZoomIn} className="flex-1 flex items-center justify-center p-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-600 border border-slate-300 shadow-sm" title="Zoom in"><ZoomIn className="w-3.5 h-3.5" /></button>
            <button onClick={handleZoomOut} className="flex-1 flex items-center justify-center p-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-600 border border-slate-300 shadow-sm" title="Zoom out"><ZoomOut className="w-3.5 h-3.5" /></button>
          </div>
          <button onClick={handleReset} className="text-[11px] font-semibold px-2 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-600 border border-slate-300 shadow-sm transition-colors">↺ Reset View</button>

          {zoom > 1 && (
            <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
              <Move className="w-3 h-3" /> Drag · scroll
            </div>
          )}
        </div>
      </div>


    </div>
  );
}