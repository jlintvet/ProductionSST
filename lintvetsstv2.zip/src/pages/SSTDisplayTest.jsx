// src/pages/SSTDisplayTest.jsx — Display Test POC v8 (MapLibre + Stadia + clipped land)
//
// KEY FIX: Pre-fetch NE land BEFORE map init. Add synchronously in map.on("load").
// Uses NE 10m land for OBX barrier island detail.
// Layer order: background(opaque) → sst-layer → water(transparent) → roads/labels
// The trick: background stays opaque for land. water fill set transparent for ocean.
// SST inserted between background and park_fill so land fills cover it.

import React, { useState, useEffect, useRef, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAppContext } from "@/context/AppContext";
import AppShell from "@/components/shell/AppShell";

const STADIA_KEY   = "abfba505-036b-4a75-acef-5689d6716b36";
const STADIA_STYLE = `https://tiles.stadiamaps.com/styles/alidade_smooth.json?api_key=${STADIA_KEY}`;
const LAND_BEIGE   = "#f2f3f0";

// ─── MapLibre CDN loader ──────────────────────────────────────────────────
function useMapLibre() {
  const [ready, setReady] = useState(typeof window !== "undefined" && !!window.maplibregl);
  useEffect(() => {
    if (ready) return;
    if (!document.getElementById("maplibre-css")) {
      const l = document.createElement("link");
      l.id="maplibre-css"; l.rel="stylesheet";
      l.href="https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.css";
      document.head.appendChild(l);
    }
    if (!document.getElementById("maplibre-js")) {
      const s = document.createElement("script");
      s.id="maplibre-js";
      s.src="https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.js";
      s.onload = () => setReady(true);
      document.head.appendChild(s);
    } else {
      const t = setInterval(() => { if (window.maplibregl) { setReady(true); clearInterval(t); }}, 100);
      return () => clearInterval(t);
    }
  }, []);
  return ready;
}

// ─── Color helpers ────────────────────────────────────────────────────────
const SST_STOPS = [
  [0,    [15,  40,  140]],
  [0.2,  [0,   130, 200]],
  [0.4,  [0,   200, 180]],
  [0.6,  [50,  210, 50 ]],
  [0.75, [255, 220, 0  ]],
  [0.9,  [255, 120, 0  ]],
  [1,    [220, 30,  30 ]],
];
function interpColor(t, stops) {
  let lo = stops[0], hi = stops[stops.length-1];
  for (let i=0; i<stops.length-1; i++) {
    if (t >= stops[i][0] && t <= stops[i+1][0]) { lo=stops[i]; hi=stops[i+1]; break; }
  }
  const lt = (t-lo[0])/(hi[0]-lo[0]);
  return [
    Math.round(lo[1][0]+(hi[1][0]-lo[1][0])*lt),
    Math.round(lo[1][1]+(hi[1][1]-lo[1][1])*lt),
    Math.round(lo[1][2]+(hi[1][2]-lo[1][2])*lt),
  ];
}
function sstColor(val, min, max) {
  if (val==null||!Number.isFinite(val)) return null;
  return interpColor(Math.max(0,Math.min(1,(val-min)/(max-min))), SST_STOPS);
}

// ─── SST canvas → blob URL ────────────────────────────────────────────────
function gridToImageURL(latSet, lonSet, grid, valMin, valMax) {
  if (!latSet.length||!lonSet.length) return null;
  const latNorth=latSet[0], latSouth=latSet[latSet.length-1];
  const lonWest=lonSet[0],  lonEast=lonSet[lonSet.length-1];
  const lonRange=lonEast-lonWest||1;
  const W=512, H=400;
  const canvas=document.createElement("canvas"); canvas.width=W; canvas.height=H;
  const ctx=canvas.getContext("2d");
  const img=ctx.createImageData(W,H); const d=img.data;
  const latStep=latSet.length>1?(latNorth-latSouth)/(latSet.length-1):0.05;
  const lonStep=lonSet.length>1?(lonEast-lonWest)/(lonSet.length-1):0.05;
  const mercY=lat=>Math.log(Math.tan(Math.PI/4+(lat*Math.PI/180)/2));
  const invMercY=y=>(2*Math.atan(Math.exp(y))-Math.PI/2)*180/Math.PI;
  const mYN=mercY(latNorth), mYS=mercY(latSouth), mYR=mYN-mYS||1;
  for (let py=0;py<H;py++) {
    const lat=invMercY(mYN-(py/(H-1))*mYR);
    const lf=(latNorth-lat)/latStep;
    const li=Math.max(0,Math.min(latSet.length-2,Math.floor(lf)));
    const lfrac=Math.max(0,Math.min(1,lf-li));
    const gl0=latSet[li], gl1=latSet[li+1];
    for (let px=0;px<W;px++) {
      const lon=lonWest+(px/(W-1))*lonRange;
      const lof=(lon-lonWest)/lonStep;
      const loi=Math.max(0,Math.min(lonSet.length-2,Math.floor(lof)));
      const lofrac=Math.max(0,Math.min(1,lof-loi));
      const glo0=lonSet[loi], glo1=lonSet[loi+1];
      const vNW=grid[`${gl0}_${glo0}`], vNE=grid[`${gl0}_${glo1}`];
      const vSW=grid[`${gl1}_${glo0}`], vSE=grid[`${gl1}_${glo1}`];
      const wNW=(1-lfrac)*(1-lofrac), wNE=(1-lfrac)*lofrac;
      const wSW=lfrac*(1-lofrac),     wSE=lfrac*lofrac;
      let sum=0,wsum=0;
      if (vNW!=null&&Number.isFinite(vNW)){sum+=vNW*wNW;wsum+=wNW;}
      if (vNE!=null&&Number.isFinite(vNE)){sum+=vNE*wNE;wsum+=wNE;}
      if (vSW!=null&&Number.isFinite(vSW)){sum+=vSW*wSW;wsum+=wSW;}
      if (vSE!=null&&Number.isFinite(vSE)){sum+=vSE*wSE;wsum+=wSE;}
      if (wsum<0.25) continue;
      const rgb=sstColor(sum/wsum,valMin,valMax); if (!rgb) continue;
      const i=(py*W+px)*4;
      d[i]=rgb[0];d[i+1]=rgb[1];d[i+2]=rgb[2];d[i+3]=210;
    }
  }
  ctx.putImageData(img,0,0);
  return new Promise(resolve=>{
    canvas.toBlob(blob=>{
      if (!blob){resolve(null);return;}
      resolve({
        url: URL.createObjectURL(blob),
        west:lonWest-lonStep/2, east:lonEast+lonStep/2,
        north:latNorth+latStep/2, south:latSouth-latStep/2,
      });
    },"image/png");
  });
}

// ─── SST normalization ────────────────────────────────────────────────────
function normalizeSSTResponse(res) {
  const data=res?.data??res;
  const firstGrid=data?.days?.[0]?.grid;
  if (Array.isArray(data?.days)&&data.days.length>0&&Array.isArray(firstGrid)&&firstGrid.length>0)
    return {ok:true,data};
  const isFC=data?.type==="FeatureCollection"&&Array.isArray(data?.features);
  if (isFC) {
    const grid=data.features.map(f=>{
      const c=f?.geometry?.coordinates,v=f?.properties?.sst;
      if (!Array.isArray(c)||c.length<2||v==null||!Number.isFinite(v)) return null;
      return {lon:c[0],lat:c[1],sst:v};
    }).filter(Boolean);
    if (!grid.length) return {ok:false,data:{days:[]}};
    const vals=grid.map(d=>d.sst);
    return {ok:true,data:{days:[{date:new Date().toISOString().slice(0,10),
      grid,stats:{min:Math.min(...vals),max:Math.max(...vals)}}]}};
  }
  return {ok:false,data:{days:[]}};
}

function Badge({label,color="gray"}) {
  const cls={
    green:"bg-green-100 text-green-800 border-green-300",
    yellow:"bg-yellow-100 text-yellow-800 border-yellow-300",
    red:"bg-red-100 text-red-800 border-red-300",
    gray:"bg-slate-100 text-slate-600 border-slate-300",
    blue:"bg-blue-100 text-blue-800 border-blue-300",
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] font-semibold ${cls[color]}`}>{label}</span>;
}

// ═════════════════════════════════════════════════════════════════════════════
// MAP COMPONENT
// ═════════════════════════════════════════════════════════════════════════════
function DisplayTestMap({heatmapData,sstMin,sstMax}) {
  const {regionConfig}=useAppContext();
  const mapDivRef=useRef(null), mapRef=useRef(null), mapReadyRef=useRef(false), blobUrlRef=useRef(null);
  const [mapReady,setMapReady]=useState(false);
  const [sstReady,setSstReady]=useState(false);
  const [error,setError]=useState(null);
  const [sstOpacity,setSstOpacity]=useState(0.85);
  const [info,setInfo]=useState("initializing");

  const rb=regionConfig.bounds;
  const mlBounds=[rb.west,rb.south,rb.east,rb.north];
  const mlReady=useMapLibre();

  useEffect(()=>{
    if (!mlReady||!mapDivRef.current||mapRef.current) return;
    const ml=window.maplibregl;
    let map;
    try {
      map=new ml.Map({
        container:mapDivRef.current,
        style:STADIA_STYLE,
        center:[-75.0,36.5],
        zoom:6,
        maxBounds:[mlBounds[0]-0.5,mlBounds[1]-0.5,mlBounds[2]+0.5,mlBounds[3]+0.5],
        minZoom:5,maxZoom:12,
        attributionControl:true,
      });
    } catch(e) { setError(`Init: ${e.message}`); return; }

    map.on("error",e=>{
      const msg=e?.error?.message??"";
      if (msg.includes("glyph")||msg.includes("sst-")||msg.includes("ne-")) return;
      console.warn("[v8]",msg);
    });

    map.on("load",()=>{
      setInfo("zeroing water");

      // ── Zero water layers (ocean = transparent → SST shows through) ────
      try{map.setPaintProperty("water","fill-color","rgba(0,0,0,0)");}catch(_){}
      try{map.setPaintProperty("water","fill-opacity",0);}catch(_){}
      try{map.setPaintProperty("waterway","line-opacity",0);}catch(_){}
      ["water_name_line","water_name_nonocean","water_name_ocean"].forEach(id=>{
        try{map.setPaintProperty(id,"text-opacity",0);}catch(_){}
      });

      // ── Insert SST raster AFTER background, BEFORE park_fill ──────────
      // background (beige) stays opaque → land stays beige at all zooms
      // SST sits between background and park_fill
      // park_fill + landcover + landuse paint over SST on land
      // water (now transparent) exposes SST in ocean
      //
      // This is the correct stack:
      //   background[beige] → SST[raster] → park/landcover/landuse[beige] → water[0] → roads → labels
      //
      // Why this works: background covers land AND ocean with beige.
      // SST is above background so SST covers both land and ocean too.
      // But then park_fill/landcover/landuse paint over SST wherever land polygons exist.
      // And water is transparent so SST shows through in ocean.
      // The only gap: bare land not covered by any Stadia fill polygon.
      //
      // Solution for bare land: add a catch-all fill from the openmaptiles
      // source using the landuse layer with NO filter, then a second one
      // using landcover. These together cover all land types.
      // For truly bare/undeveloped land at low zoom: use park source with
      // no filter, which in OpenMapTiles covers all land areas at z4+.

      // ── Build correct layer stack ─────────────────────────────────────
      // Target order:
      //   0: background (beige, opaque — land color baseline)
      //   1: sst-layer (SST raster — sits above background)  ← added in SST effect
      //   2: v8-land-landuse (beige fill — covers SST on land)
      //   3: v8-land-landcover (beige fill — covers SST on land)
      //   4: park_fill, landcover_*, landuse (Stadia originals)
      //  12: water (opacity 0 — transparent ocean exposes SST)
      //  ...: roads, labels
      //
      // We add the land fills here synchronously. SST is added later in
      // the SST effect and inserted BEFORE v8-land-landuse, putting it
      // at index 1 — below all land fills but above background.

      try {
        map.addLayer({
          id:"v8-land-landuse", type:"fill",
          source:"openmaptiles", "source-layer":"landuse",
          paint:{"fill-color":LAND_BEIGE,"fill-opacity":1},
        },"park_fill");
      } catch(e){console.warn("[v8] landuse:",e.message);}

      try {
        map.addLayer({
          id:"v8-land-landcover", type:"fill",
          source:"openmaptiles", "source-layer":"landcover",
          paint:{"fill-color":LAND_BEIGE,"fill-opacity":1},
        },"park_fill");
      } catch(e){console.warn("[v8] landcover:",e.message);}

      setInfo("ready");
      mapReadyRef.current=true;
      setMapReady(true);
    });

    mapRef.current=map;
    return ()=>{
      if (blobUrlRef.current){try{URL.revokeObjectURL(blobUrlRef.current);}catch(_){}}
      map.remove(); mapRef.current=null; mapReadyRef.current=false;
    };
  },[mlReady]);

  // ── SST raster effect ─────────────────────────────────────────────────────
  useEffect(()=>{
    const map=mapRef.current;
    if (!map||!mapReadyRef.current||!heatmapData?.latSet?.length) return;
    setSstReady(false); let cancelled=false;

    const timer=setTimeout(()=>{
      Promise.resolve(
        gridToImageURL(heatmapData.latSet,heatmapData.lonSet,heatmapData.grid,sstMin,sstMax)
      ).then(result=>{
        if (cancelled||!result||!mapRef.current) return;
        const {url,west,east,north,south}=result;
        if (blobUrlRef.current){try{URL.revokeObjectURL(blobUrlRef.current);}catch(_){}}
        blobUrlRef.current=url;
        const m=mapRef.current;
        try{m.removeLayer("sst-layer");}catch(_){}
        try{m.removeSource("sst-source");}catch(_){}
        m.addSource("sst-source",{
          type:"image", url,
          coordinates:[[west,north],[east,north],[east,south],[west,south]],
        });
        // Insert SST BEFORE v8-land-landuse so land fills render above it.
        // Final stack: background → SST → v8-land-landuse → v8-land-landcover → park_fill → ... → water(0) → roads
        m.addLayer({
          id:"sst-layer", type:"raster", source:"sst-source",
          paint:{
            "raster-opacity":sstOpacity,
            "raster-resampling":"linear",
            "raster-fade-duration":0,
          },
        },"v8-land-landuse");
        setSstReady(true);
      });
    },300);
    return ()=>{cancelled=true;clearTimeout(timer);};
  },[mapReady,heatmapData,sstMin,sstMax]);

  useEffect(()=>{
    const map=mapRef.current;
    if (!map||!mapReady||!sstReady) return;
    try{map.setPaintProperty("sst-layer","raster-opacity",sstOpacity);}catch(_){}
  },[sstOpacity,mapReady,sstReady]);

  if (error) return (
    <div className="flex-1 flex items-center justify-center p-4">
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-700"><b>Error:</b> {error}</div>
    </div>
  );

  return (
    <div className="flex flex-col h-full gap-2 p-2">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-bold text-slate-700">Display Test POC — v8b</span>
        <Badge
          label={!mlReady?"⏳ MapLibre…":!mapReady?`⏳ ${info}`:sstReady?"✓ SST rendering":"⏳ SST…"}
          color={sstReady?"green":"yellow"}
        />
        <Badge label="bg→SST→land fills→water(0)→roads" color="blue"/>
      </div>
      <div className="flex items-center gap-4 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 flex-shrink-0">
        <label className="flex items-center gap-2 text-xs text-slate-600 font-medium">
          SST opacity
          <input type="range" min={0.3} max={1.0} step={0.05} value={sstOpacity}
            onChange={e=>setSstOpacity(parseFloat(e.target.value))} className="w-20 accent-cyan-600"/>
          <span className="tabular-nums w-8 text-slate-400">{Math.round(sstOpacity*100)}%</span>
        </label>
      </div>
      <div ref={mapDivRef}
        className="flex-1 rounded-lg border border-slate-200 overflow-hidden"
        style={{minHeight:400,background:"#c8e8f0"}}
      />
      <div className="flex items-center gap-2 flex-shrink-0">
        <span className="text-[10px] text-slate-400">Cold</span>
        <div className="h-3 rounded flex-1 max-w-xs" style={{
          background:"linear-gradient(to right,rgb(15,40,140),rgb(0,130,200),rgb(0,200,180),rgb(50,210,50),rgb(255,220,0),rgb(255,120,0),rgb(220,30,30))",
        }}/>
        <span className="text-[10px] text-slate-400">Warm</span>
        <span className="text-[10px] text-slate-300 ml-2">{sstMin?.toFixed(0)}°F → {sstMax?.toFixed(0)}°F</span>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// PAGE BODY
// ═════════════════════════════════════════════════════════════════════════════
function SSTDisplayTestBody() {
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState(null);
  const [sstData,setSstData]=useState(null);

  useEffect(()=>{
    setLoading(true);
    base44.functions.invoke("sstSummary",{})
      .then(res=>{
        const r=normalizeSSTResponse(res);
        if (r.ok) setSstData(r.data);
        else setError("SST response not recognized.");
      })
      .catch(e=>setError(e.message))
      .finally(()=>setLoading(false));
  },[]);

  const {heatmapData,sstMin,sstMax}=useMemo(()=>{
    const ag=sstData?.days?.[sstData.days.length-1]?.grid;
    const as=sstData?.days?.[sstData.days.length-1]?.stats;
    if (!ag?.length) return {heatmapData:null,sstMin:32,sstMax:85};
    const latSet=[...new Set(ag.map(d=>d.lat))].sort((a,b)=>b-a);
    const lonSet=[...new Set(ag.map(d=>d.lon))].sort((a,b)=>a-b);
    const grid={}; ag.forEach(d=>{grid[`${d.lat}_${d.lon}`]=d.sst;});
    const vals=ag.map(d=>d.sst).filter(v=>v!=null).sort((a,b)=>a-b);
    const min=vals.length?vals[Math.floor(vals.length*0.02)]:(as?.min??32);
    const max=vals.length?vals[Math.floor(vals.length*0.98)]:(as?.max??85);
    return {heatmapData:{latSet,lonSet,grid},sstMin:min,sstMax:max};
  },[sstData]);

  if (loading) return (
    <div className="flex-1 flex items-center justify-center">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-cyan-500 rounded-full animate-spin"/>
        <p className="text-sm text-slate-500">Loading SST data…</p>
      </div>
    </div>
  );
  if (error) return <div className="p-4"><div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-700"><b>Error:</b> {error}</div></div>;
  if (!heatmapData) return <div className="flex-1 flex items-center justify-center text-slate-400 text-sm">No SST data.</div>;
  return <DisplayTestMap heatmapData={heatmapData} sstMin={sstMin} sstMax={sstMax}/>;
}

export default function SSTDisplayTest() {
  return (
    <AppShell region="mid_atlantic" onUpgrade={()=>{}}>
      <SSTDisplayTestBody/>
    </AppShell>
  );
}
